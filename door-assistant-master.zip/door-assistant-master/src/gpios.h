#include "mgos_gpio.h"

bool open_door();
void init_gpios();
